import React from 'react'

const ThankYou = () => {
  return (
    <div>
      
    </div>
  )
}

export default ThankYou
