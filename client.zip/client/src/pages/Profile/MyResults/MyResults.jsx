import React from 'react'

const MyResults = () => {
  return (
    <>
      
    </>
  )
}

export default MyResults
